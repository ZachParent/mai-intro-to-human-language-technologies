* [x] build a feature selection process (use dependency-based feature elimination)
* [x] use synsets to build features
* [x] create a way to identify which feature pipelines are most important
    * [x] maybe a table to decode the pipeline in a CSV
* [x] try new similarity metrics
* [ ] presentation
	* [ ] add explanation for wordpairs and ngrams
	- [x] add references to UKP and the competition paper
	- [x] add plots
		- [x] make plots light themed
- [ ] get review from friends

* only the results in the notebook will be considered
* slides must be submitted by the deadline
